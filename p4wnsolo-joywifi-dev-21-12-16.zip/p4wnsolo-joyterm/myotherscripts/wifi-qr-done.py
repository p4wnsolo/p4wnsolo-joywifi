#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) 2014-2020 Richard Hull and contributors
# See LICENSE.rst for details.
# PYTHON_ARGCOMPLETE_OK

"""
Greyscale rendering demo.
"""

import SH1106
import time
from pathlib import Path
from demo_opts import get_device
from luma.core.render import canvas
from PIL import Image
from subprocess import Popen, PIPE
from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont


#******** Generate QR Code Begin
# Here's the shell command we're running below:
#/sbin/ifconfig wlan0 | grep "inet " | cut -d "k" -f1 | cut -d "n" -f2 | cut -d "t" -f2 | cut -d " " -f2

prefix = '/root/BeBoXGui/'
filepath = './qr/qr.png'
part1 = '/sbin/ifconfig wlan0 | grep "inet "'  # First half of shell command
part2 = ' | cut -d "k" -f1 | cut -d "n" -f2 | cut -d "t" -f2 | cut -d " " -f2'  #2nd

path = 'qr $(' + part1 + part2 + ') > ' + filepath  # Define the full command

pipe = Popen(path, stdout=PIPE, shell='True')  
text = pipe.communicate()[0]
#******** Generate QR Code End

# Init some variables
size_x = 63
size_y = 63
sleep_time = 3
font1 = 'fonts/Prototype.ttf'
fontsize1 = 14
thefont1 = ImageFont.truetype(prefix + font1, fontsize1)
font2 = 'fonts/Prototype.ttf'
fontsize2 = 16
thefont2 = ImageFont.truetype(prefix + font2, fontsize2)

# 240x240 display with hardware SPI:
disp = SH1106.SH1106()
disp.Init()

# Define main function
def main():
    theqrcode = Image.open(filepath) \
        .resize((size_x, size_y)) \
        .transform(device.size, Image.AFFINE, (1, 0, 0, 0, 1, 0), Image.BILINEAR) \
        .convert("L") \
        .convert(device.mode) \
#        .rotate(180) \

    while True:
        # Image display
        #device.display(theqrcode)

        #device.display(theqrcode)

        # Create blank image for drawing.
        # Make sure to create image with mode '1' for 1-bit color.
        image = Image.new('1', (disp.width, disp.height), "WHITE")

        # Get drawing object to draw on image.
        draw = ImageDraw.Draw(theqrcode)

        # Draw the selection Box
        draw.rectangle(((64, 0), (127, 64)), fill="white")
        draw.rectangle(((64, 26), (127, 45)), fill="black")
        draw.text((65,2), 'QR Code', font = thefont1, fill = 0)
        draw.text((65,25), u'SSH', font = thefont2, fill = 255)
        draw.text((65,45), 'xyz123', font = thefont1, fill = 0)

        #draw.text((0,32), u'           X Found', font = thefont2, fill = 0)
        #image1=image1.rotate(0) 
        #draw.rectangle((10,30,60,60), outline=0, fill=1) #center filled
        disp.ShowImage(disp.getbuffer(theqrcode.rotate(180)))

        time.sleep(sleep_time)

        # Greyscale
        shades = 16
        w = device.width / shades
        for _ in range(2):
            with canvas(device, dither=True) as draw:
                #for i, color in enumerate(range(0, 256, shades)):
                #    rgb = (color << 16) | (color << 8) | color
                #    draw.rectangle((i * w, 0, (i + 1) * w, device.height), fill=rgb)

                size = draw.textsize("QR Code")
                left = (device.width - size[0]) // 2
                top = (device.height - size[1]) // 2
                right = left + size[0]
                bottom = top + size[1]
                #draw.rectangle((left - 1, top, right, bottom), fill="black")
                draw.rectangle(device.bounding_box, outline="white")
                draw.text((left, top), text="QR Code", fill="white")

        time.sleep(sleep_time)


if __name__ == "__main__":
    try:
        device = get_device()
        main()
    except KeyboardInterrupt:
        pass
