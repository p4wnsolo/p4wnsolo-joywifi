# -*- coding:utf-8 -*-

#import
import subprocess
import SH1106
from PIL import Image,ImageDraw,ImageFont
import time
import pathlib
from pathlib import Path

# Open subprocess and launch iwconfig
s = subprocess.check_output('iwconfig')

# Fonts
prefix = str(pathlib.Path(__file__).parent.resolve()) + '/'
font_filename = 'fonts/DroidSansMono.ttf'
font11 = ImageFont.truetype(prefix + font_filename, 11)
font12 = ImageFont.truetype(prefix + font_filename, 12)
font13 = ImageFont.truetype(prefix + font_filename, 13)
font16 = ImageFont.truetype(prefix + font_filename, 16)


# Convert output to string for processing
s = str(s)

# Check if string was found
check_essid = "ESSID:\"" in s

# Print if "SSID" was found in iwconfig results
print("\n\n***ESSID found: " + str(check_essid))

# If ESSID was found, continue
if str(check_essid) == "True":
    # Clear screen and Print 'Connection Error' on line 2
    try:
        disp = SH1106.SH1106()
        disp.Init()
        disp.clear()
        image1 = Image.new('1', (disp.width, disp.height), "WHITE")
        draw = ImageDraw.Draw(image1)
        draw.line([(0,0),(127,0)], fill = 0)
        draw.line([(0,0),(0,63)], fill = 0)
        draw.line([(0,63),(127,63)], fill = 0)
        draw.line([(127,0),(127,63)], fill = 0)
        draw.text((3,5), 'Connected to WiFi', font = font11, fill = 0)
        #image1=image1.rotate(0) 
        disp.ShowImage(disp.getbuffer(image1))
        time.sleep(2)
        #Himage2 = Image.new('1', (disp.width, disp.height), 255)
        #bmp = Image.open('pic.bmp')
        #Himage2.paste(bmp, (0,0))    
        #disp.ShowImage(disp.getbuffer(Himage2))
        #time.sleep(2)
        #disp.clear()
        #image2 = Image.new('1', (disp.width, disp.height), "WHITE")
        #draw2 = ImageDraw.Draw(image2)
        #IPAddress = str(get_ip_address())
        #draw2.text((0,0), IPAddress, font = font16, fill = 0)
        #disp.ShowImage(disp.getbuffer(image2))
    except IOError as e:
        print(e)
    except KeyboardInterrupt:    
        print("ctrl + c:")
        epdconfig.module_exit()
    print("Connected to WiFi! ***\n\n")

    # Print the iwconfig output.  Uncomment for debug
    #print(str(s) + "\n")

    # Check if another string was found
    if str(s).find("Link Quality=") == -1:
        print("No 'Link Quality' here!")
    else:
        print("Found 'Link Quality' in the string.")


    # Get ESSID from iwconfig output
    t = s.split("ESSID:\"")
    u = t[1].split("\"")
    v = u[0]

    # Print ESSID
    print("\nESSID: ")
    print(v)

    # Get Link Quality from iwconfig output
    w = s.split("Link Quality=")
    # Split the result on the "/" character to get Link Quality
    x = w[1].split("/")
    # Set final LinkQuality variable from first result of previous split
    lq = x[0]

    # Print Link Quality
    print("Link Quality: ")
    print(lq) # Link Quality

    # Get Link Quality "out of"
    z = x[1].split("  Signal level=")  # Split the string to get LQ "out of" 
    # Set final LinkQualityOutOf variable from first result of previous split
    lqo = z[0]

    # Print LinkQualityOutOf
    print("Out of: ")
    print(lqo) # Link Quality "out of" (second #, ex: 50/70, this is 70)

    # Calculate % from Link Quality 
    link_quality_percent = int((int(lq) / int(lqo) * 100))
    link_quality_display = str(link_quality_percent) + "%"
    print(link_quality_display)


    # Print Link Quality on OLED screen
    draw.text((3,22), u'Link Quality:' + link_quality_display, font = font11, fill = 0)
    disp.ShowImage(disp.getbuffer(image1))
    time.sleep(2)


    # Check if string was found
    check_link = " Link Quality=" in s
    print("Link Quality found: " + str(check_link))

    # Get SSID (simplest method - uses iwgetid)
    #output = subprocess.check_output(['iwgetid'])
    #print("Connected Wifi SSID: " + str(output).split('"')[1])

    print("\n")

    # Open subprocess and launch ping
    #j = subprocess.check_output('ping -c2 google.com',shell=True)
    #j = str(j)

    try:
        output = subprocess.check_output('ping -c5 google.com', stderr=subprocess.STDOUT, shell=True, timeout=5,universal_newlines=True)
    except subprocess.CalledProcessError as exc:
        print("Status : FAIL", exc.returncode, exc.output)
        # Option to reset WiFi ?
        # P4wnP1_cli template deploy -w startup
    else:
        print("Output: \n{}\n".format(output))

        j = str(output)

        # Check packet loss
        zero_packet_loss = " 0% packet loss" in j

        print("\n")

        print("j = " + j)

        print("\n")

        if zero_packet_loss == True:
            print("\n0% Packet Loss? " + str(zero_packet_loss))
            print("Ping google.com successful")
            try:
                draw.text((1,42), u'Internet Connected', font = font11, fill = 0)
                #image1=image1.rotate(0) 
                disp.ShowImage(disp.getbuffer(image1))
                time.sleep(2)
                #Himage2 = Image.new('1', (disp.width, disp.height), 255)
                #bmp = Image.open('pic.bmp')
                #Himage2.paste(bmp, (0,0))    
                #disp.ShowImage(disp.getbuffer(Himage2))
                #time.sleep(2)
                #disp.clear()
                #image2 = Image.new('1', (disp.width, disp.height), "WHITE")
                #draw2 = ImageDraw.Draw(image2)
                #IPAddress = str(get_ip_address())
                #draw2.text((0,0), IPAddress, font = font16, fill = 0)
                #disp.ShowImage(disp.getbuffer(image2))
            except IOError as e:
                print(e)
            except KeyboardInterrupt:    
                print("ctrl + c:")
                epdconfig.module_exit()
            
        else:
            print("Unable to Ping Google / Packet Loss Detected")
        

    print('\n\n')
else:
    # Clear screen and Print 'Connection Error' on line 2
    try:
        disp = SH1106.SH1106()
        disp.Init()
        disp.clear()
        image1 = Image.new('1', (disp.width, disp.height), "WHITE")
        draw = ImageDraw.Draw(image1)
        draw.line([(0,0),(127,0)], fill = 0)
        draw.line([(0,0),(0,63)], fill = 0)
        draw.line([(0,63),(127,63)], fill = 0)
        draw.line([(127,0),(127,63)], fill = 0)
        #draw.text((0,8), '    Connecting', font = font16, fill = 0)
        draw.text((0,32), u'   Connection Error', font = font13, fill = 0)
        #image1=image1.rotate(0) 
        disp.ShowImage(disp.getbuffer(image1))
        time.sleep(2)
        #Himage2 = Image.new('1', (disp.width, disp.height), 255)
        #bmp = Image.open('pic.bmp')
        #Himage2.paste(bmp, (0,0))    
        #disp.ShowImage(disp.getbuffer(Himage2))
        #time.sleep(2)
        #disp.clear()
        #image2 = Image.new('1', (disp.width, disp.height), "WHITE")
        #draw2 = ImageDraw.Draw(image2)
        #IPAddress = str(get_ip_address())
        #draw2.text((0,0), IPAddress, font = font16, fill = 0)
        #disp.ShowImage(disp.getbuffer(image2))
    except IOError as e:
        print(e)
    except KeyboardInterrupt:    
        print("ctrl + c:")
        epdconfig.module_exit()
        exit()
    exit()