# -*- coding:utf-8 -*-

#import
import subprocess

# Try to turn off WiFi
try:
    output = subprocess.check_output('sudo ifconfig wlan0 up', stderr=subprocess.STDOUT, shell=True, timeout=3,universal_newlines=True)
except subprocess.CalledProcessError as exc:
    print("Status : FAIL", exc.returncode, exc.output)
# Do this if successful
else:
    # Print the output
    print("Output: \n{}\n".format(output))

    try:
        output = subprocess.check_output('iwconfig wlan0', stderr=subprocess.STDOUT, shell=True, timeout=3,universal_newlines=True)
    except subprocess.CalledProcessError as exc:
        print("Status : FAIL", exc.returncode, exc.output)
    # Do this if successful
    else:
        # Convert output to string for processing
        s = str(output)

        # Check if string was found - should return True or False
        check_tx = "Tx-Power" in s
        check_tx = str(check_tx)

        # Print if "Tx-Power" was found in iwconfig results
        print("***Tx-Power found: " + check_tx)

        exit()


