# -*- coding:utf-8 -*-
import subprocess

try:
    output = subprocess.check_output('P4wnP1_cli template deploy -w startup', stderr=subprocess.STDOUT, shell=True, timeout=3,universal_newlines=True)
except subprocess.CalledProcessError as exc:
    print("Status : FAIL", exc.returncode, exc.output)
else:
    print("Output: \n{}\n".format(output))


