#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) 2014-2020 Richard Hull and contributors
# See LICENSE.rst for details.
# PYTHON_ARGCOMPLETE_OK

"""
Greyscale rendering demo.
"""

import time
from pathlib import Path
from demo_opts import get_device
from luma.core.render import canvas
from PIL import Image
from subprocess import Popen, PIPE

#******** Generate QR Code Begin
# Here's the shell command we're running below:
#/sbin/ifconfig wlan0 | grep "inet " | cut -d "k" -f1 | cut -d "n" -f2 | cut -d "t" -f2 | cut -d " " -f2

filepath = './qr/qr.png'
part1 = '/sbin/ifconfig wlan0 | grep "inet "'  # First half of shell command
part2 = ' | cut -d "k" -f1 | cut -d "n" -f2 | cut -d "t" -f2 | cut -d " " -f2'  #2nd

path = 'qr $(' + part1 + part2 + ') > ' + filepath  # Define the full command

pipe = Popen(path, stdout=PIPE, shell='True')  
text = pipe.communicate()[0]
#******** Generate QR Code End

# Init some variables
size_x = 63
size_y = 63
sleep_time = 5

# Define main function
def main():
    theqrcode = Image.open(filepath) \
        .resize((size_x, size_y)) \
        .transform(device.size, Image.AFFINE, (1, 0, 0, 0, 1, 0), Image.BILINEAR) \
        .convert("L") \
        .convert(device.mode) \
		.rotate(180) \

    while True:
        # Image display
        device.display(theqrcode)
        #device.display(theqrcode)
        time.sleep(sleep_time)



if __name__ == "__main__":
    try:
        device = get_device()
        main()
    except KeyboardInterrupt:
        pass
