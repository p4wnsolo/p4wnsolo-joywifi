# -*- coding:utf-8 -*-
import SH1106
import time
import config
import traceback
import subprocess
import socket
import fcntl
import struct
import pathlib
from pathlib import Path

import RPi.GPIO as GPIO

from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

#GPIO define
RST_PIN        = 25
CS_PIN         = 8
DC_PIN         = 24

KEY_UP_PIN     = 6 
KEY_DOWN_PIN   = 19
KEY_LEFT_PIN   = 5
KEY_RIGHT_PIN  = 26
KEY_PRESS_PIN  = 13

KEY1_PIN       = 21
KEY2_PIN       = 20
KEY3_PIN       = 16

# Initialize variables
prefix = str(pathlib.Path(__file__).parent.resolve()) + '/'
ssid_file = prefix + 'ssid.txt'
Path(ssid_file).touch(exist_ok=True)
ssids_file = prefix + 'ssids.txt'
Path(ssids_file).touch(exist_ok=True)
ssid_in_ssids = prefix + 'savedssidinssids.txt'
Path(ssid_in_ssids).touch(exist_ok=True)
text_file_name = prefix + 'reconnect.txt'        
Path(text_file_name).touch(exist_ok=True)
wifi_autorecon_file = prefix + 'dontreconnect.txt'
Path(wifi_autorecon_file).touch(exist_ok=True)
wifi_cfg_file = prefix + 'wificfg.txt'
Path(wifi_cfg_file).touch(exist_ok=True)
wpa_file_name = prefix + 'wpa.cnf'
Path(wpa_file_name).touch(exist_ok=True)

font1 = 'fonts/DroidSansMono.ttf'
fontsize1 = 18
thefont1 = ImageFont.truetype(prefix + font1, fontsize1)

font2 = 'fonts/Prototype.ttf'
fontsize2 = 18
thefont2 = ImageFont.truetype(prefix + font2, fontsize2)
fontsize3 = 14
thefont3 = ImageFont.truetype(prefix + font2, fontsize3)

# Set text offseet
text_offset_y = 0
fontsize = 11
text_multiplier_y = fontsize
text_offset_x = 0

# 240x240 display with hardware SPI:
disp = SH1106.SH1106()
disp.Init()

z = 59

# Set default selection
selection = 2

# Read saved WiFi info from wpa_file_name
with open(wpa_file_name, 'r') as f:
    savedssid = f.readlines()[0]
    savedssid = savedssid.strip('\n')
    #print(line1)
with open(wpa_file_name, 'r') as f:
    savedpw = f.readlines()[1]
    savedpw = savedpw.strip('\n')
    #print(line1)
with open(ssids_file, 'r') as f:
    if savedssid in f.read():
        open(ssid_in_ssids, 'w').close()  # Open the file and clear it
        f = open(ssid_in_ssids, "a")  #  Open it again for Append mode
        f.write('True')  # Write the selected_response to the file
        #print("true")
        #savedpw = savedpw.strip('\n')

        print('\nSaved SSID was found in SSID list.  Asking if user wants to reconnect.\n')
        # Show the reconnect script

        line2 = savedssid



        # Set lower limit of selection (4 lines numbered from 0, so "YES" would be 2)
        sel_limit_lower = 2

        #Set upper limit of selection (4 lines numbered from 0, so "NO" would be 3)
        sel_limit_upper = 4

        # (Check if the saved SSID is online)
        #  if f.readlines(wpa_file_name, line0) in ssids.txt:
        #   If it's there, then show the askreconnect script.
        #      Network is online and saved - ask to reconnect to it (continue this script)
        #   If it's not there, then skip the ask reconnect script.
        #      Network is offline - don't reconnect to it (show the disp.py and pw.py scripts)
            
        # Get IP Address
        #logging.info("Getting IP Address")
        def get_ip_address():
         ip_address = '';
         s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
         s.connect(("8.8.8.8",80))
         ip_address = s.getsockname()[0]
         s.close()
         return ip_address

        # Clear display.
        disp.clear()
        # time.sleep(1)

        #init GPIO
        # for P4:
        # sudo vi /boot/config.txt
        # gpio=6,19,5,26,13,21,20,16=pu
        GPIO.setmode(GPIO.BCM) 
        GPIO.setup(KEY_UP_PIN,      GPIO.IN, pull_up_down=GPIO.PUD_UP)    # Input with pull-up
        GPIO.setup(KEY_DOWN_PIN,    GPIO.IN, pull_up_down=GPIO.PUD_UP)  # Input with pull-up
        GPIO.setup(KEY_LEFT_PIN,    GPIO.IN, pull_up_down=GPIO.PUD_UP)  # Input with pull-up
        GPIO.setup(KEY_RIGHT_PIN,   GPIO.IN, pull_up_down=GPIO.PUD_UP) # Input with pull-up
        GPIO.setup(KEY_PRESS_PIN,   GPIO.IN, pull_up_down=GPIO.PUD_UP) # Input with pull-up
        GPIO.setup(KEY1_PIN,        GPIO.IN, pull_up_down=GPIO.PUD_UP)      # Input with pull-up
        GPIO.setup(KEY2_PIN,        GPIO.IN, pull_up_down=GPIO.PUD_UP)      # Input with pull-up
        GPIO.setup(KEY3_PIN,        GPIO.IN, pull_up_down=GPIO.PUD_UP)      # Input with pull-up

        # Create blank image for drawing.
        # Make sure to create image with mode '1' for 1-bit color.
        image = Image.new('1', (disp.width, disp.height), "WHITE")

        # Get drawing object to draw on image.
        draw = ImageDraw.Draw(image)

        # try:
        myfont = ImageFont.truetype(prefix + font1, fontsize)    
        #font16 = ImageFont.truetype('Font.ttf', 16)    

        while 1:

            # with canvas(device) as draw:
            if GPIO.input(KEY_UP_PIN): # button is released
                #draw.polygon([(38, 5), (48, 0), (58, 5)], outline=255, fill=0)  #Up
                print("UP was pressed and released")
            else:   #button is pressed:
                # Create blank image for drawing.
                # Make sure to create image with mode '1' for 1-bit color.
                image = Image.new('1', (disp.width, disp.height), "WHITE")

                # Get drawing object to draw on image.
                draw = ImageDraw.Draw(image)
                if selection > sel_limit_lower:
                    selection = selection - 1
                elif selection == sel_limit_lower:
                    selection = sel_limit_upper
                selection_y1 = ((selection * text_multiplier_y) + 11)
                selection_y2 = ((selection * text_multiplier_y) + 23)
                #draw.polygon([(38, 5), (48, 0), (58, 5)], outline=0, fill=1)  #Up filled
                print("Up")
                
            if GPIO.input(KEY_LEFT_PIN): # button is released
                print("UP was pressed and released")
                #draw.polygon([(0, 30), (6, 21), (6, 41)], outline=255, fill=0)  #left
                #image2 = Image.new('1', (disp.width, disp.height), "WHITE")
                #draw2 = ImageDraw.Draw(image2)
                #IPAddress = str(get_ip_address())
                #draw2.text((0,0), "IP Address:", font = font16, fill = 0)
                #draw2.text((0,17), IPAddress, font = font16, fill = 0)
                #image2=image2.rotate(180) 
                #disp.ShowImage(disp.getbuffer(image2))
            else:     # button is pressed:
                print("UP was pressed and released")
                #draw.polygon([(0, 30), (6, 21), (6, 41)], outline=0, fill=1)  #left filled
                #image2 = Image.new('1', (disp.width, disp.height), "WHITE")
                #draw2 = ImageDraw.Draw(image2)
                #IPAddress = str(get_ip_address())
                #draw2.text((0,0), "IP Address:", font = font16, fill = 0)
                #draw2.text((0,17), "Hello World", font = font16, fill = 0)
                #image2=image2.rotate(180) 
                #disp.ShowImage(disp.getbuffer(image2))
                print("left")
                #time.sleep(2)
                
            if GPIO.input(KEY_RIGHT_PIN): # button is released
                print("UP was pressed and released")
                #draw.polygon([(95, 30), (89, 21), (89, 41)], outline=255, fill=0) #right
            else: # button is pressed:
                #draw.polygon([(95, 30), (89, 21), (89, 41)], outline=0, fill=1) #right filled
                print("right")
                
            if GPIO.input(KEY_DOWN_PIN): # button is released
                print("DOWN was pressed and released")
                #if selection == 2:
                #draw.polygon([(48, 60), (58, 54), (38, 54)], outline=255, fill=0) #down
            else: # button is pressed:
                # Create blank image for drawing.
                # Make sure to create image with mode '1' for 1-bit color.
                image = Image.new('1', (disp.width, disp.height), "WHITE")

                # Get drawing object to draw on image.
                draw = ImageDraw.Draw(image)

                # Increment the Selection counter if the user hasn't reached the last item yet
                if selection < sel_limit_upper:
                    selection = selection + 1
                elif selection == sel_limit_upper:
                    selection = sel_limit_lower
                selection_y1 = ((selection * text_multiplier_y) + text_offset_y + 1)
                selection_y2 = ((selection * text_multiplier_y) + fontsize + 2)
                #if selection == 2:
                #draw.rectangle((selection_y1, 19,88,selection_y2), outline=255, fill=1) #center filled
                #draw.polygon([(48, 60), (58, 54), (38, 54)], outline=0, fill=1) #down filled
                print("down")
                print(selection)
            
            if GPIO.input(KEY_PRESS_PIN): # CENTER button is released     
                # Make sure to create image with mode '1' for 1-bit color.
                image = Image.new('1', (disp.width, disp.height), "WHITE")

                # Get drawing object to draw on image.
                draw = ImageDraw.Draw(image)
            
                # Set y-coordinates of selection Box according to the value of "selection" variable
                selection_y1 = ((selection * text_multiplier_y) + text_offset_y + 1)
                selection_y2 = ((selection * text_multiplier_y) + fontsize + 2)

                # Draw the selection Box
                draw.rectangle((text_offset_x, selection_y1,98,selection_y2), outline=0, fill=1) #center filled

                #draw.rectangle((8, 6,88,22), outline=0, fill=1) # Draw a big square around inner area 

                # Read menu items from txt file
                with open(text_file_name, 'r') as f:
                    line1 = f.readlines()[0]
                    print(line1)
                with open(text_file_name, 'r') as f:
                    line2 = f.readlines()[1]
                    print(line2)
                with open(text_file_name, 'r') as f:
                    line3 = f.readlines()[2]
                    print(line3)
                with open(text_file_name, 'r') as f:
                    line4 = f.readlines()[3]
                    print(line4)
                with open(text_file_name, 'r') as f:
                    line5 = f.readlines()[4]
                    print(line5)


                # Print the current selection to the console
                print("Current selection: " + str(selection))

                if z > 10:
                    z = z - 1
                else:
                    selected_response = 'Yes'
                    print('\nYes - Reconnect to previously saved network')
                    print('\n' + savedssid + savedpw)
                    
                    image1 = Image.new('1', (disp.width, disp.height), "WHITE")
                    draw = ImageDraw.Draw(image1)

                    draw.text((1,2), 'Reconnecting..', font = thefont2, fill = 0)
                    draw.rectangle(((0, 26), (127, 45)), fill="black")
                    #draw.text((0,32), u'           X Found', font = thefont2, fill = 0)
                    #image1=image1.rotate(0) 
                    disp.ShowImage(disp.getbuffer(image1))


                    # Here is where we need to do a try command. Handle 2 cases:  "Error" and "Wrong PSK"
                    subprocess.call(['P4wnP1_cli', 'wifi', 'set', 'sta', '-n', '-s', savedssid, '-k', savedpw])
                    autoreconnecting = 1
                    # sleep 8 seconds while reconnecting
                    #time.sleep(2)

                    open(wifi_autorecon_file, 'w').close()  # Open the file and clear it
                    f = open(wifi_autorecon_file, "a")  #  Open it again for Append mode
                    f.write('False')  # Write the selected_response to the file
                    
                    open(wifi_cfg_file, 'w').close()  # Open the file and clear it
                    f = open(wifi_cfg_file, "a")  #  Open it again for Append mode
                    f.write(selected_response)  # Write the selected_response to the file

                    # Clear display.
                    #disp.clear()
                
                    # Draw the text!
                    #draw.text((9, 6), oled_line_1, font = myfont, fill = 0)
                    #draw.text((9, 20), oled_line_2, font = myfont, fill = 0)
                    #draw.text((9, 34), oled_line_3, font = myfont, fill = 0)
                    print("\nSelected Response: " + selected_response + '\n')
                    print("center")
                    draw.text((0,25), u'   Connected!', font = thefont2, fill = 255)
                    draw.text((0,45), '     Please wait..', font = thefont2, fill = 0)
                    disp.ShowImage(disp.getbuffer(image1))
                    exit()

                # Set OLED text line variables
                oled_line_1 = line1
                oled_line_2 = line2
                oled_line_3 = '     ' + line3.strip() + ' (' + str(int(z/10)) + ')'
                oled_line_4 = '      ' + line4.strip()
                oled_line_5 = line5
            
                # Draw the text!
                draw.text((text_offset_x + 1, ((text_multiplier_y*0)+text_offset_y)), oled_line_1, font = myfont, fill = 0)
                draw.text((text_offset_x + 1, ((text_multiplier_y*1)+text_offset_y)), oled_line_2, font = myfont, fill = 0)
                draw.text((text_offset_x + 1, ((text_multiplier_y*2)+text_offset_y)), oled_line_3, font = myfont, fill = 0)
                draw.text((text_offset_x + 1, ((text_multiplier_y*3)+text_offset_y)), oled_line_4, font = myfont, fill = 0)
                draw.text((text_offset_x + 1, ((text_multiplier_y*4)+text_offset_y)), savedssid, font = myfont, fill = 0)
                #disp.clear()

            else: # CENTER button is pressed:
                #draw.text((9, 9), "Menu Item #1", font = myfont, fill = 1)

                #draw.rectangle((8, 6,88,22), outline=255, fill=1) #center filled
                #draw.rectangle((8, 6,88,52), outline=0, fill=1) # Full rectangle 

                # Set y-coordinates of selection Box according to the value of "selection" variable
                selection_y1 = ((selection * text_multiplier_y) + text_offset_y)
                selection_y2 = ((selection * text_multiplier_y) + text_offset_y + fontsize)

                # Draw the selection Box
                draw.rectangle((text_offset_x, selection_y1,88,selection_y2), outline=0, fill=1) #center filled
            
                # Get the line that corresponds with the user's selection
                # Read menu items from txt file
                with open(text_file_name, 'r') as f:
                    selected_response = f.readlines()[selection]
            
                # If "Yes - and remember my choice", do this:
                if 'remember' in selected_response:
                    print('\nYes - And remember my answer')
                    print('\n' + savedssid + savedpw)
                # If "Yes", do this:
                elif 'Yes' in selected_response:
                    print('\nYes - Reconnect to previously saved network')
                    print('\n' + savedssid + savedpw)
                    
                    image1 = Image.new('1', (disp.width, disp.height), "WHITE")
                    draw = ImageDraw.Draw(image1)

                    draw.text((1,2), 'Reconnecting..', font = thefont2, fill = 0)
                    draw.rectangle(((0, 26), (127, 45)), fill="black")
                    #draw.text((0,32), u'           X Found', font = thefont2, fill = 0)
                    #image1=image1.rotate(0) 
                    disp.ShowImage(disp.getbuffer(image1))


                    # Here is where we need to do a try command. Handle 2 cases:  "Error" and "Wrong PSK"
                    subprocess.call(['P4wnP1_cli', 'wifi', 'set', 'sta', '-n', '-s', savedssid, '-k', savedpw])
                    autoreconnecting = 1
                    # sleep 8 seconds while reconnecting
                    #time.sleep(2)

                    open(wifi_autorecon_file, 'w').close()  # Open the file and clear it
                    f = open(wifi_autorecon_file, "a")  #  Open it again for Append mode
                    f.write('False')  # Write the selected_response to the file
                    
                    open(wifi_cfg_file, 'w').close()  # Open the file and clear it
                    f = open(wifi_cfg_file, "a")  #  Open it again for Append mode
                    f.write(selected_response)  # Write the selected_response to the file

                    # Clear display.
                    #disp.clear()
                
                    # Draw the text!
                    #draw.text((9, 6), oled_line_1, font = myfont, fill = 0)
                    #draw.text((9, 20), oled_line_2, font = myfont, fill = 0)
                    #draw.text((9, 34), oled_line_3, font = myfont, fill = 0)
                    print("\nSelected Response: " + selected_response + '\n')
                    print("center")
                    draw.text((0,25), u'   Connected!', font = thefont2, fill = 255)
                    draw.text((0,45), '     Please wait..', font = thefont3, fill = 0)
                    disp.ShowImage(disp.getbuffer(image1))

                    # Clear display.
                    #disp.clear()


                # If "No", do this:
                elif 'No' in selected_response:
                    print('\nNo - Do not reconnect\n')
                    open(wifi_autorecon_file, 'w').close()  # Open the file and clear it
                    f = open(wifi_autorecon_file, "a")  #  Open it again for Append mode
                    f.write('True')  # Write the selected_response to the file


                # Exit the script
                exit()

                
            if GPIO.input(KEY1_PIN): # button is released
                nothing = 0
                #draw.ellipse((100,0,120,20), outline=255, fill=0) #A button
            else: # button is pressed:
                print("KEY1")
                #draw.ellipse((100,0,120,20), outline=0, fill=1) #A button filled
                
            if GPIO.input(KEY2_PIN): # button is released
                draw.ellipse((100,20,120,40), outline=255, fill=0) #B button]
            else: # button is pressed:
                draw.ellipse((100,20,120,40), outline=0, fill=1) #B button filled
                print("KEY2")
                
            if GPIO.input(KEY3_PIN): # button is released
                draw.ellipse((100,40,120,60), outline=255, fill=0) #A button
            else: # button is pressed:
                draw.ellipse((100,40,120,60), outline=0, fill=1) #A button filled
                print("KEY3")
                
            disp.ShowImage(disp.getbuffer(image))
                
        # except:
            # print("except")
        # GPIO.cleanup()
    else:
        print('\nDid NOT find saved SSID in SSID list.  Skipping "ask-reconnect" script.\n')
        open(ssid_in_ssids, 'w').close()  # Open the file and clear it
        f = open(ssid_in_ssids, "a")  #  Open it again for Append mode
        f.write('False')  # Write the selected_response to the file


