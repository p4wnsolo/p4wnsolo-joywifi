#!/usr/bin/python
# -*- coding:utf-8 -*-

import subprocess
import pathlib

prefix = str(pathlib.Path(__file__).parent.resolve()) + '/'
pydir = '/usr/bin/python3'


#subprocess.call([pydir, prefix + 'wifi-splash-launch.py'])
subprocess.call(['sudo', pydir, prefix + 'joywifi-scanwifi.py', 'wlan0'])
subprocess.call([pydir, prefix + 'joywifi-askreconnect.py'])  # Uses wificfg.txt
subprocess.call([pydir, prefix + 'joywifi-selectwifi.py'])  # Uses ssid.txt, ssids.txt
subprocess.call([pydir, prefix + 'joywifi-getpw.py'])   # Uses wpa.cnf
subprocess.call([pydir, prefix + 'joywifi-checkwifi.py']) #
subprocess.call([pydir, prefix + 'joywifi-ask2save.py'])  # Uses wificfg.txt
subprocess.call([pydir, prefix + 'joywifi-dashdemo.py'])  # Uses wificfg.txt

# DONE :  Skip disp when reconnecting
# To do:  Skip pw when reconnecting

#wifi-splash-launch.py &&	#Splash screen
#wifi-scan.py wlan0 &&  		#Scan for WiFi
#wifi-askreconnect.py && 	#Ask to reconnect
#wifi-disp.py && 			#Display WiFi networks
#wifi-pw-skiptest.py &&		#Display PW input screen
#wifi-chek.py &&				#Check connection
#wifi-asksave.py				#Ask to save network
#wifi-disp-adv-fontsize.py	#Show main Dashboard

