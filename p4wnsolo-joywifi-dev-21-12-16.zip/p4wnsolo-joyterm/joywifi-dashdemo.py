# -*- coding:utf-8 -*-
import SH1106
import time
import config
import traceback
import subprocess
import socket
import fcntl
import struct
import fontawesome as fa
import pathlib
from pathlib import Path

import RPi.GPIO as GPIO

from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

#GPIO define
RST_PIN        = 25
CS_PIN         = 8
DC_PIN         = 24

KEY_UP_PIN     = 6 
KEY_DOWN_PIN   = 19
KEY_LEFT_PIN   = 5
KEY_RIGHT_PIN  = 26
KEY_PRESS_PIN  = 13

KEY1_PIN       = 21
KEY2_PIN       = 20
KEY3_PIN       = 16


# 240x240 display with hardware SPI:
disp = SH1106.SH1106()
disp.Init()

#Init variables
fontsize = 10
fontsize2 = 10
text_multiplier_y = fontsize
theiconsize = 14
theiconsize2 = 10

# Set text offseet
text_offset_x = 6
text_offset_y = 12
# Set KEY1234 button variables
key123_x_offset = 113
key123_y_offset = -2
key123_height = 16
key123_width = 16        
key123_left_x = key123_x_offset
key123_right_x = key123_left_x + key123_width
# Set battery coordinates
batt_x_offset = 115
batt_y_offset = 55
# Set message icon coordinates
msg_x_offset = 116
msg_y_offset = 46

# Init variables 
prefix = str(pathlib.Path(__file__).parent.resolve()) + '/'
fontfile = prefix + 'fonts/DroidSansMono.ttf'  # Editor's number 1 pick
fontfile2 = prefix + 'fonts/DroidSansMono.ttf'  # Editor's number 1 pick
iconfile = prefix + 'fonts/fontawesome-webfont.ttf'  # FontAwesome   #fontawesome-webfont.ttf
ssid_file = prefix + 'ssid.txt'
mainmenu_file = prefix + 'menu-dash.txt'

myfont = ImageFont.truetype(fontfile, fontsize)    
myfont2 = ImageFont.truetype(fontfile2, fontsize2)    
theiconfont = ImageFont.truetype(iconfile, theiconsize)    
theiconfont2 = ImageFont.truetype(iconfile, theiconsize2)    


# Get IP Address
#logging.info("Getting IP Address")
def get_ip_address():
 ip_address = '';
 s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
 s.connect(("8.8.8.8",80))
 ip_address = s.getsockname()[0]
 s.close()
 return ip_address

# Clear display.
disp.clear()
# time.sleep(1)

#init GPIO
# for P4:
# sudo vi /boot/config.txt
# gpio=6,19,5,26,13,21,20,16=pu
GPIO.setmode(GPIO.BCM) 
GPIO.setup(KEY_UP_PIN,      GPIO.IN, pull_up_down=GPIO.PUD_UP)    # Input with pull-up
GPIO.setup(KEY_DOWN_PIN,    GPIO.IN, pull_up_down=GPIO.PUD_UP)  # Input with pull-up
GPIO.setup(KEY_LEFT_PIN,    GPIO.IN, pull_up_down=GPIO.PUD_UP)  # Input with pull-up
GPIO.setup(KEY_RIGHT_PIN,   GPIO.IN, pull_up_down=GPIO.PUD_UP) # Input with pull-up
GPIO.setup(KEY_PRESS_PIN,   GPIO.IN, pull_up_down=GPIO.PUD_UP) # Input with pull-up
GPIO.setup(KEY1_PIN,        GPIO.IN, pull_up_down=GPIO.PUD_UP)      # Input with pull-up
GPIO.setup(KEY2_PIN,        GPIO.IN, pull_up_down=GPIO.PUD_UP)      # Input with pull-up
GPIO.setup(KEY3_PIN,        GPIO.IN, pull_up_down=GPIO.PUD_UP)      # Input with pull-up

# Create blank image for drawing.
# Make sure to create image with mode '1' for 1-bit color.
image = Image.new('1', (disp.width, disp.height), "WHITE")

# Get drawing object to draw on image.
draw = ImageDraw.Draw(image)

# try:

selection = 0

while 1:

    # with canvas(device) as draw:
    if GPIO.input(KEY_UP_PIN): # button is released
        #draw.polygon([(38, 5), (48, 0), (58, 5)], outline=255, fill=0)  #Up
        print("UP was pressed and released")
    else:   #button is pressed:
        # Create blank image for drawing.
        # Make sure to create image with mode '1' for 1-bit color.
        image = Image.new('1', (disp.width, disp.height), "WHITE")

        # Get drawing object to draw on image.
        draw = ImageDraw.Draw(image)
        if selection > 0:
            selection = selection - 1
        selection_y1 = ((selection * text_multiplier_y) + 11)
        selection_y2 = ((selection * text_multiplier_y) + 23)
        #draw.polygon([(38, 5), (48, 0), (58, 5)], outline=0, fill=1)  #Up filled
        print("Up")
        
    if GPIO.input(KEY_LEFT_PIN): # button is released
        print("UP was pressed and released")
        #draw.polygon([(0, 30), (6, 21), (6, 41)], outline=255, fill=0)  #left
        #image2 = Image.new('1', (disp.width, disp.height), "WHITE")
        #draw2 = ImageDraw.Draw(image2)
        #IPAddress = str(get_ip_address())
        #draw2.text((0,0), "IP Address:", font = font16, fill = 0)
        #draw2.text((0,17), IPAddress, font = font16, fill = 0)
        #image2=image2.rotate(180) 
        #disp.ShowImage(disp.getbuffer(image2))
    else:     # button is pressed:
        print("UP was pressed and released")
        #draw.polygon([(0, 30), (6, 21), (6, 41)], outline=0, fill=1)  #left filled
        #image2 = Image.new('1', (disp.width, disp.height), "WHITE")
        #draw2 = ImageDraw.Draw(image2)
        #IPAddress = str(get_ip_address())
        #draw2.text((0,0), "IP Address:", font = font16, fill = 0)
        #draw2.text((0,17), "Hello World", font = font16, fill = 0)
        #image2=image2.rotate(180) 
        #disp.ShowImage(disp.getbuffer(image2))
        print("left")
        #time.sleep(2)
        
    if GPIO.input(KEY_RIGHT_PIN): # button is released
        print("UP was pressed and released")
        #draw.polygon([(95, 30), (89, 21), (89, 41)], outline=255, fill=0) #right
    else: # button is pressed:
        #draw.polygon([(95, 30), (89, 21), (89, 41)], outline=0, fill=1) #right filled
        print("right")
        
    if GPIO.input(KEY_DOWN_PIN): # button is released
        print("DOWN was pressed and released")
        #if selection == 2:
        #draw.polygon([(48, 60), (58, 54), (38, 54)], outline=255, fill=0) #down
    else: # button is pressed:
        # Create blank image for drawing.
        # Make sure to create image with mode '1' for 1-bit color.
        image = Image.new('1', (disp.width, disp.height), "WHITE")

        # Get drawing object to draw on image.
        draw = ImageDraw.Draw(image)

        # Increment the Selection counter if the user hasn't reached the last item yet
        if selection < 3:
            selection = selection + 1
        selection_y1 = ((selection * text_multiplier_y) + text_offset_y + 1)
        selection_y2 = ((selection * text_multiplier_y) + fontsize + 2)
        #if selection == 2:
        #draw.rectangle((selection_y1, 19,88,selection_y2), outline=255, fill=1) #center filled
        #draw.polygon([(48, 60), (58, 54), (38, 54)], outline=0, fill=1) #down filled
        print("down")
        print(selection)
    
    if GPIO.input(KEY_PRESS_PIN): # CENTER button is released        
        # Set y-coordinates of selection Box according to the value of "selection" variable
        selection_y1 = ((selection * text_multiplier_y) + text_offset_y + 1)
        selection_y2 = ((selection * text_multiplier_y) + fontsize + 2)

        # Draw the selection Box
        draw.rectangle((text_offset_x, selection_y1,110,selection_y2 + text_offset_y), outline=0, fill=1) #center filled

        #draw.rectangle((8, 6,88,22), outline=0, fill=1) # Draw a big square around inner area 

        # Read menu items from txt file
        with open(mainmenu_file, 'r') as f:
            line1 = f.readlines()[0]
            print(line1)
        with open(mainmenu_file, 'r') as f:
            line2 = f.readlines()[1]
            print(line2)
        with open(mainmenu_file, 'r') as f:
            line3 = f.readlines()[2]
            print(line3)
        with open(mainmenu_file, 'r') as f:
            line4 = f.readlines()[3]
            print(line4)
        with open(mainmenu_file, 'r') as f:
            line5 = f.readlines()[4]
            print(line5)

        # Print the current selection to the console
        print("Current selection: " + str(selection))
    
        # Set OLED text line variables
        oled_line_1 = line1
        oled_line_2 = line2
        oled_line_3 = line3
        oled_line_4 = line4
        oled_line_5 = line5

        # Set font-awesome icon
        faicon1 = fa.icons['signal'] + ' ' + fa.icons['globe'] + ' ' + fa.icons['eye'] + ' ' + fa.icons['bluetooth'] + ' ' + fa.icons['tv'] + ' ' + fa.icons['server'] 
        #faicon1 = fa.icons['battery-half'] + ' ' + fa.icons['user-secret'] + ' ' + fa.icons['eye-slash'] + ' ' + fa.icons['battery-full'] + ' ' + fa.icons['eye'] + ' ' + fa.icons['bug'] 
        #faicon2 = fa.icons['signal'] + fa.icons['wifi'] + fa.icons['bluetooth'] + fa.icons['wifi'] + fa.icons['toggle-off'] + fa.icons['plug'] 
        faicon2 = 'Status: Gro0vy'
        faicon3 = fa.icons['battery-half']
        faicon4 = fa.icons['envelope']
        
        # Working icons that look decent:
        #     server, lock, user-secret, bug
        
        # Working icon pairs that look decent:
        #      pairs:  signal/unlink (wifiLinkQ/no), eye/eye-slash (tor/noTor), battery-full/half
        #                globe/ban (internet/no)
        
        # Draw the top icons!
        draw.text((0, -1), faicon1, font = theiconfont, fill = 0)
        # Draw the selection box!
        draw.rectangle((0,text_offset_y + 1,text_offset_x,51), outline=0, fill=255) #center filled
        # Draw the status bar background!
        draw.rectangle((0,53,key123_left_x,64), outline=0, fill=0) #center filled
        # Draw the status bar text!
        draw.text((0, 52), faicon2, font = myfont2, fill = 255) #Good at 14px with solid BG
        # Draw the message icon!
        draw.text((msg_x_offset, msg_y_offset), faicon4, font = theiconfont2, fill = 0) #Good at 14px with solid BG
        # Draw the battery icon!
        draw.text((batt_x_offset, batt_y_offset), faicon3, font = theiconfont2, fill = 0) #Good at 14px with solid BG
    
        # Draw the text!
        draw.text((text_offset_x + 1, ((text_multiplier_y*0)+text_offset_y)), oled_line_1, font = myfont, fill = 0)
        draw.text((text_offset_x + 1, ((text_multiplier_y*1)+text_offset_y)), oled_line_2, font = myfont, fill = 0)
        draw.text((text_offset_x + 1, ((text_multiplier_y*2)+text_offset_y)), oled_line_3, font = myfont, fill = 0)
        draw.text((text_offset_x + 1, ((text_multiplier_y*3)+text_offset_y)), oled_line_4, font = myfont, fill = 0)

    else: # CENTER button is pressed:
        #draw.text((9, 9), "Menu Item #1", font = myfont, fill = 1)

        #draw.rectangle((8, 6,88,22), outline=255, fill=1) #center filled
        #draw.rectangle((8, 6,88,52), outline=0, fill=1) # Full rectangle 

        # Set y-coordinates of selection Box according to the value of "selection" variable
        selection_y1 = ((selection * text_multiplier_y) + text_offset_y)
        selection_y2 = ((selection * text_multiplier_y) + text_offset_y + fontsize)

        # Draw the selection Box
        draw.rectangle((text_offset_x, selection_y1,88,selection_y2), outline=0, fill=1) #center filled
    
        # Get the line that corresponds with the user's selection
        # Read menu items from txt file
        with open(mainmenu_file, 'r') as f:
            selected_wifi = f.readlines()[selection]
    
        open(ssid_file, 'w').close()  # Open the file and clear it
        f = open(ssid_file, "a")  #  Open it again for Append mode
        f.write(selected_wifi)  # Write the selected_wifi to the file

        # Clear display.
        disp.clear()
    
        # Draw the text!
        #draw.text((9, 6), oled_line_1, font = myfont, fill = 0)
        #draw.text((9, 20), oled_line_2, font = myfont, fill = 0)
        #draw.text((9, 34), oled_line_3, font = myfont, fill = 0)
        print("\nSelected WiFi: " + selected_wifi + '\n')
        print("center")

        # Clear display.
        disp.clear()

        # Exit the script
        exit()

    if GPIO.input(KEY1_PIN): # button is released
        draw.ellipse((key123_left_x,key123_y_offset,key123_right_x,key123_y_offset + key123_height), outline=255, fill=0) #A button
    else: # button is pressed:
        draw.ellipse((key123_left_x,key123_y_offset,key123_right_x,key123_y_offset + key123_height), outline=0, fill=1) #A button filled
        print("KEY1")
        
    if GPIO.input(KEY2_PIN): # button is released
        draw.ellipse((key123_left_x,key123_y_offset + key123_height,key123_right_x,key123_y_offset + key123_height*2), outline=255, fill=0) #B button]
    else: # button is pressed:
        draw.ellipse((key123_left_x,key123_y_offset + key123_height,key123_right_x,key123_y_offset + key123_height*2), outline=0, fill=1) #B button filled
        print("KEY2")
        
    if GPIO.input(KEY3_PIN): # button is released
        draw.ellipse((key123_left_x,key123_y_offset + key123_height*2,key123_right_x,key123_y_offset + key123_height*3), outline=255, fill=0) #A button
    else: # button is pressed:
        draw.ellipse((key123_left_x,key123_y_offset + key123_height*2,key123_right_x,key123_y_offset + key123_height*3), outline=255, fill=0) #A button
        print("KEY3")
        
    disp.ShowImage(disp.getbuffer(image))
    
# except:
    # print("except")
# GPIO.cleanup()
