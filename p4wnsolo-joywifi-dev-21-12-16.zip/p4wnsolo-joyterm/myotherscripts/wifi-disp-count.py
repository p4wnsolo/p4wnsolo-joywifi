# -*- coding:utf-8 -*-
import SH1106
import time
import config
import traceback
import subprocess
import socket
import fcntl
import struct
import RPi.GPIO as GPIO
from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

#GPIO define
RST_PIN        = 25
CS_PIN         = 8
DC_PIN         = 24

KEY_UP_PIN     = 6 
KEY_DOWN_PIN   = 19
KEY_LEFT_PIN   = 5
KEY_RIGHT_PIN  = 26
KEY_PRESS_PIN  = 13

KEY1_PIN       = 21
KEY2_PIN       = 20
KEY3_PIN       = 16

# Init variables
prefix = '/root/BeBoXGui/'
ssid_file = prefix + 'ssid.txt'
ssids_file = prefix + 'ssids.txt'
wifi_autorecon_file = prefix + 'dontreconnect.txt'
wpa_file_name = prefix + 'wpa.cnf'
z_init = 109
z_end = 10
z_decrement = 1
z = z_init
    
# Set text offseet
fontsize = 11
text_multiplier_y = fontsize
text_offset_x = 0
text_offset_y = 0



##### Here's how this file needs to operate:  (wifi-disp and wifi-asksave)
# If PW is known AND SSID is in ssids.txt
#       do not show disp
# If PW is known AND SSID is NOT in ssids.txt
#       show disp
# If PW is unknown OR SSID is NOT in ssids.txt
#        show disp


# Check if we're reconnecting before showing the WiFi select menu
# Read saved WiFi info from wpa_file_name
with open(wpa_file_name, 'r') as f:
    savedssid = f.readlines()[0]
    savedssid = savedssid.strip('\n')
    #print(line1)
with open(wpa_file_name, 'r') as f:
    savedpw = f.readlines()[1]
    savedpw = savedpw.strip('\n')
    #print(line1)
with open(wifi_autorecon_file, 'r') as f:
    dontreconnect = f.readlines()[0]
    dontreconnect = str(dontreconnect.strip('\n'))
    print('\nDontReconnect = ' + dontreconnect + '\n')
with open(ssids_file, 'r') as f:
    if savedssid not in f.read() or dontreconnect == 'True':
        print('\nSaved SSID was not found in SSIDs file.  Showing WiFi scan results.\n')

        # 240x240 display with hardware SPI:
        disp = SH1106.SH1106()
        disp.Init()

        # Get IP Address
        def get_ip_address():
         ip_address = '';
         s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
         s.connect(("8.8.8.8",80))
         ip_address = s.getsockname()[0]
         s.close()
         return ip_address

        # Clear display.
        disp.clear()

        #init GPIO
        # for P4:
        # sudo vi /boot/config.txt
        # gpio=6,19,5,26,13,21,20,16=pu
        GPIO.setmode(GPIO.BCM) 
        GPIO.setup(KEY_UP_PIN,      GPIO.IN, pull_up_down=GPIO.PUD_UP)    # Input with pull-up
        GPIO.setup(KEY_DOWN_PIN,    GPIO.IN, pull_up_down=GPIO.PUD_UP)  # Input with pull-up
        GPIO.setup(KEY_LEFT_PIN,    GPIO.IN, pull_up_down=GPIO.PUD_UP)  # Input with pull-up
        GPIO.setup(KEY_RIGHT_PIN,   GPIO.IN, pull_up_down=GPIO.PUD_UP) # Input with pull-up
        GPIO.setup(KEY_PRESS_PIN,   GPIO.IN, pull_up_down=GPIO.PUD_UP) # Input with pull-up
        GPIO.setup(KEY1_PIN,        GPIO.IN, pull_up_down=GPIO.PUD_UP)      # Input with pull-up
        GPIO.setup(KEY2_PIN,        GPIO.IN, pull_up_down=GPIO.PUD_UP)      # Input with pull-up
        GPIO.setup(KEY3_PIN,        GPIO.IN, pull_up_down=GPIO.PUD_UP)      # Input with pull-up

        # Create blank image for drawing.
        # Make sure to create image with mode '1' for 1-bit color.
        image = Image.new('1', (disp.width, disp.height), "WHITE")

        # Get drawing object to draw on image.
        draw = ImageDraw.Draw(image)

        # Create dynamic font sizes
        myfont = ImageFont.truetype(prefix + 'Font.ttf', fontsize)    

        # Set default selection
        selection = 0

        # Start the loop
        while 1:
            # with canvas(device) as draw:
            if GPIO.input(KEY_UP_PIN): # button is released
                #draw.polygon([(38, 5), (48, 0), (58, 5)], outline=255, fill=0)  #Up
                print("UP was pressed and released")
            else:   #button is pressed:
                # Create blank image for drawing.
                image = Image.new('1', (disp.width, disp.height), "WHITE")

                # Get drawing object to draw on image.
                draw = ImageDraw.Draw(image)
                if selection > 0:
                    selection = selection - 1
                selection_y1 = ((selection * text_multiplier_y) + 11)
                selection_y2 = ((selection * text_multiplier_y) + 23)
                #draw.polygon([(38, 5), (48, 0), (58, 5)], outline=0, fill=1)  #Up filled
                print("Up")
                
            if GPIO.input(KEY_LEFT_PIN): # button is released
                print("LEFT was pressed and released")
            else:     # button is pressed:
                print("LEFT was pressed and released")
                
            if GPIO.input(KEY_RIGHT_PIN): # button is released
                print("RIGHT was pressed and released")
                #draw.polygon([(95, 30), (89, 21), (89, 41)], outline=255, fill=0) #right
            else: # button is pressed:
                #draw.polygon([(95, 30), (89, 21), (89, 41)], outline=0, fill=1) #right filled
                print("right")
                
            if GPIO.input(KEY_DOWN_PIN): # button is released
                print("DOWN was pressed and released")
                #draw.polygon([(48, 60), (58, 54), (38, 54)], outline=255, fill=0) #down
            else: # button is pressed:
                # Create blank image for drawing.
                image = Image.new('1', (disp.width, disp.height), "WHITE")

                # Get drawing object to draw on image.
                draw = ImageDraw.Draw(image)

                # Increment the Selection counter if the user hasn't reached the last item yet
                if selection < 3:
                    selection = selection + 1
                selection_y1 = ((selection * text_multiplier_y) + text_offset_y + 1)
                selection_y2 = ((selection * text_multiplier_y) + fontsize + 2)
                #if selection == 2:
                #draw.rectangle((selection_y1, 19,88,selection_y2), outline=255, fill=1) #center filled
                #draw.polygon([(48, 60), (58, 54), (38, 54)], outline=0, fill=1) #down filled
                print("down")
                print(selection)
            
            if GPIO.input(KEY_PRESS_PIN): # CENTER button is released        
                # Set y-coordinates of selection Box according to the value of "selection" variable
                selection_y1 = ((selection * text_multiplier_y) + text_offset_y + 1)
                selection_y2 = ((selection * text_multiplier_y) + fontsize + 2)

                # Draw the selection Box
                draw.rectangle((text_offset_x, selection_y1,98,selection_y2), outline=0, fill=1) #center filled

                #draw.rectangle((8, 6,88,22), outline=0, fill=1) # Draw a big square around inner area 

                # Read menu items from txt file
                with open(ssids_file, 'r') as f:
                    line1 = f.readlines()[0]
                    print(line1)
                with open(ssids_file, 'r') as f:
                    line2 = f.readlines()[1]
                    print(line2)
                with open(ssids_file, 'r') as f:
                    line3 = f.readlines()[2]
                    print(line3)
#                with open(ssids_file, 'r') as f:
#                    line4 = f.readlines()[3]
#                    print(line4)
#                with open(ssids_file, 'r') as f:
#                    line5 = f.readlines()[4]
#                    print(line5)

                # Print the current selection to the console
                print("Current selection: " + str(selection))
                print(str(z))


                if z > z_end:
                    z = z - z_decrement
                else:
                    print('\nZ is less than 10.\n')
                    subprocess.call(['sudo', '/usr/bin/python3', '/root/BeBoXGui/wifi-scan.py', 'wlan0']) #
                    z = z_init


                # Set OLED text line variables
                oled_line_1 = line1
                oled_line_2 = line2
                oled_line_3 = line3
#               oled_line_4 = line4
                oled_line_5 = ' Refresh in ' + '   (' + str(int(z/10)) + ')'
            
                # Create blank image for drawing.
                # Make sure to create image with mode '1' for 1-bit color.
                image = Image.new('1', (disp.width, disp.height), "WHITE")

                # Get drawing object to draw on image.
                draw = ImageDraw.Draw(image)

                # Draw the selection Box
                draw.rectangle((text_offset_x, selection_y1,88,selection_y2), outline=0, fill=1) #center filled
            


                # Draw the text!
                draw.text((text_offset_x + 1, ((text_multiplier_y*0)+text_offset_y)), oled_line_1, font = myfont, fill = 0)
                draw.text((text_offset_x + 1, ((text_multiplier_y*1)+text_offset_y)), oled_line_2, font = myfont, fill = 0)
                draw.text((text_offset_x + 1, ((text_multiplier_y*2)+text_offset_y)), oled_line_3, font = myfont, fill = 0)
                draw.text((text_offset_x + 1, ((text_multiplier_y*4)+text_offset_y)), oled_line_5, font = myfont, fill = 0)
#                draw.text((text_offset_x + 1, ((text_multiplier_y*3)+text_offset_y)), oled_line_4, font = myfont, fill = 0)

            else: # CENTER button is pressed:
                #draw.text((9, 9), "Menu Item #1", font = myfont, fill = 1)

                #draw.rectangle((8, 6,88,22), outline=255, fill=1) #center filled
                #draw.rectangle((8, 6,88,52), outline=0, fill=1) # Full rectangle 

                # Set y-coordinates of selection Box according to the value of "selection" variable
                selection_y1 = ((selection * text_multiplier_y) + text_offset_y)
                selection_y2 = ((selection * text_multiplier_y) + text_offset_y + fontsize)

                # Draw the selection Box
                draw.rectangle((text_offset_x, selection_y1,88,selection_y2), outline=0, fill=1) #center filled
            
                # Get the line that corresponds with the user's selection
                # Read menu items from txt file
                with open(ssids_file, 'r') as sf:
                    selected_wifi = sf.readlines()[selection]
            
                open(ssid_file, 'w').close()  # Open the file and clear it
                f = open(ssid_file, "a")  #  Open it again for Append mode
                f.write(selected_wifi)  # Write the selected_wifi to the file
                f.close()
                sf.close()

                # Clear display.
                disp.clear()
            
                # Draw the text!
                #draw.text((9, 6), oled_line_1, font = myfont, fill = 0)
                #draw.text((9, 20), oled_line_2, font = myfont, fill = 0)
                #draw.text((9, 34), oled_line_3, font = myfont, fill = 0)
                print("\nSelected WiFi: " + selected_wifi + '\n')
                print("center")

                # Clear display.
                disp.clear()

                # Exit the script
                
                #subprocess.call(['sudo /usr/bin/python3 /root/BeBoXGui/wifi-pw-skiptest2.py'],shell=True)   # Uses wpa.cnf

                exit()
                #ssids_file.close()

                
            if GPIO.input(KEY1_PIN): # button is released
                draw.ellipse((100,0,120,20), outline=255, fill=0) #A button
            else: # button is pressed:
                draw.ellipse((100,0,120,20), outline=0, fill=1) #A button filled
                print("KEY1")
                
            if GPIO.input(KEY2_PIN): # button is released
                draw.ellipse((100,20,120,40), outline=255, fill=0) #B button]
            else: # button is pressed:
                draw.ellipse((100,20,120,40), outline=0, fill=1) #B button filled
                print("KEY2")
                
            if GPIO.input(KEY3_PIN): # button is released
                draw.ellipse((100,40,120,60), outline=255, fill=0) #A button
            else: # button is pressed:
                draw.ellipse((100,40,120,60), outline=0, fill=1) #A button filled
                print("KEY3")
                
            disp.ShowImage(disp.getbuffer(image))
            
        # except:
            # print("except")
        # GPIO.cleanup()
        
