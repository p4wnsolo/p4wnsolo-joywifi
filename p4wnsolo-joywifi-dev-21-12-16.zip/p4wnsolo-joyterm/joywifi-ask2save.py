# -*- coding:utf-8 -*-
import SH1106
import time
import config
import traceback
import subprocess
import socket
import fcntl
import struct
import pathlib
from pathlib import Path

import RPi.GPIO as GPIO

from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

#GPIO define
RST_PIN        = 25
CS_PIN         = 8
DC_PIN         = 24

KEY_UP_PIN     = 6 
KEY_DOWN_PIN   = 19
KEY_LEFT_PIN   = 5
KEY_RIGHT_PIN  = 26
KEY_PRESS_PIN  = 13

KEY1_PIN       = 21
KEY2_PIN       = 20
KEY3_PIN       = 16

# Init variables
prefix = str(pathlib.Path(__file__).parent.resolve()) + '/'
ssid_file = prefix + 'ssid.txt'
txtfilename = prefix + 'savemenu.txt'
wifi_save_file = prefix + 'wifisave.txt'

droid_font = 'fonts/DroidSansMono.ttf'

# Set text offsets
text_multiplier_y = 14
text_offset_y = 6
    
# 240x240 display with hardware SPI:
disp = SH1106.SH1106()
disp.Init()

z_init = 59
z_end = 10
z_decrement = 1
z = z_init


# Set default selection
selection = 2

# Set lower limit of selection (4 lines numbered from 0, so "YES" would be 2)
sel_limit_lower = 2

#Set upper limit of selection (4 lines numbered from 0, so "NO" would be 3)
sel_limit_upper = 3

# Get IP Address
#logging.info("Getting IP Address")
def get_ip_address():
 ip_address = '';
 s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
 s.connect(("8.8.8.8",80))
 ip_address = s.getsockname()[0]
 s.close()
 return ip_address

# Clear display.
disp.clear()
# time.sleep(1)

#init GPIO
# for P4:
# sudo vi /boot/config.txt
# gpio=6,19,5,26,13,21,20,16=pu
GPIO.setmode(GPIO.BCM) 
GPIO.setup(KEY_UP_PIN,      GPIO.IN, pull_up_down=GPIO.PUD_UP)    # Input with pull-up
GPIO.setup(KEY_DOWN_PIN,    GPIO.IN, pull_up_down=GPIO.PUD_UP)  # Input with pull-up
GPIO.setup(KEY_LEFT_PIN,    GPIO.IN, pull_up_down=GPIO.PUD_UP)  # Input with pull-up
GPIO.setup(KEY_RIGHT_PIN,   GPIO.IN, pull_up_down=GPIO.PUD_UP) # Input with pull-up
GPIO.setup(KEY_PRESS_PIN,   GPIO.IN, pull_up_down=GPIO.PUD_UP) # Input with pull-up
GPIO.setup(KEY1_PIN,        GPIO.IN, pull_up_down=GPIO.PUD_UP)      # Input with pull-up
GPIO.setup(KEY2_PIN,        GPIO.IN, pull_up_down=GPIO.PUD_UP)      # Input with pull-up
GPIO.setup(KEY3_PIN,        GPIO.IN, pull_up_down=GPIO.PUD_UP)      # Input with pull-up

# Create blank image for drawing.
# Make sure to create image with mode '1' for 1-bit color.
image = Image.new('1', (disp.width, disp.height), "WHITE")

# Get drawing object to draw on image.
draw = ImageDraw.Draw(image)

# try:
font12 = ImageFont.truetype(prefix + droid_font, 12)    
font16 = ImageFont.truetype(prefix + droid_font, 16)    


# Start the loop
while 1:
    # with canvas(device) as draw:
    if GPIO.input(KEY_UP_PIN): # UP button is released
        #draw.polygon([(38, 5), (48, 0), (58, 5)], outline=255, fill=0)  #Up
        print("UP was pressed and released")
    else:   #button is pressed:
        # Create blank image for drawing.
        image = Image.new('1', (disp.width, disp.height), "WHITE")

        # Get drawing object to draw on image.
        draw = ImageDraw.Draw(image)

        # Make the selection cycle when reached top / bottom of list
        if selection > sel_limit_lower:
            selection = selection - 1
        elif selection == sel_limit_lower:
            selection = sel_limit_upper

        # Set coordinates for selection box
        selection_y1 = ((selection * text_multiplier_y) + 11)
        selection_y2 = ((selection * text_multiplier_y) + 23)
        print("UP button was pressed")
        
    if GPIO.input(KEY_LEFT_PIN): # button is released
        print("LEFT was pressed and released")
    else:     # button is pressed:
        print("LEFT was pressed and released")
        
    if GPIO.input(KEY_RIGHT_PIN): # button is released
        print("RIGHT was pressed and released")
    else: # button is pressed:
        print("right")
        
    if GPIO.input(KEY_DOWN_PIN): # button is released
        print("DOWN was pressed and released")
        #if selection == 2:
        #draw.polygon([(48, 60), (58, 54), (38, 54)], outline=255, fill=0) #down
    else: # button is pressed:
        # Create blank image for drawing.
        image = Image.new('1', (disp.width, disp.height), "WHITE")

        # Get drawing object to draw on image.
        draw = ImageDraw.Draw(image)

        # Increment the Selection counter if the user hasn't reached the last item yet
        if selection < sel_limit_upper:
            selection = selection + 1
        elif selection == sel_limit_upper:
            selection = sel_limit_lower

        # Set coordinates for selection box
        selection_y1 = ((selection * text_multiplier_y) + 11)
        selection_y2 = ((selection * text_multiplier_y) + 23)
        #if selection == 2:
        #draw.rectangle((selection_y1, 19,88,selection_y2), outline=255, fill=1) #center filled
        #draw.polygon([(48, 60), (58, 54), (38, 54)], outline=0, fill=1) #down filled
        print("down")
        print(selection)
    
    if GPIO.input(KEY_PRESS_PIN): # CENTER button is released        
        # Set y-coordinates of selection Box according to the value of "selection" variable
        selection_y1 = ((selection * text_multiplier_y) + 7)
        selection_y2 = ((selection * text_multiplier_y) + 21)

        # Draw the selection Box
        draw.rectangle((8, selection_y1,98,selection_y2), outline=0, fill=1) #center filled
        #draw.rectangle((8, 6,88,22), outline=0, fill=1) # Draw a big square around inner area 

        # Read menu items from txt file
        with open(txtfilename, 'r') as f:
            line1 = f.readlines()[0]
            print(line1)
        with open(txtfilename, 'r') as f:
            line2 = f.readlines()[1]
            print(line2)
        with open(txtfilename, 'r') as f:
            line3 = f.readlines()[2]
            print(line3)
        with open(txtfilename, 'r') as f:
            line4 = f.readlines()[3]
            print(line4)
        #with open(txtfilename, 'r') as f:
        #    line5 = f.readlines()[4]
        #    print(line5)

        # Print the current selection to the console
        print("Current selection: " + str(selection))
        print(str(z))
    
        if z > z_end:
            z = z - z_decrement
        else:
            print('\nZ is less than 10.\n')
            with open(txtfilename, 'r') as f:
                selected_wifi = f.readlines()[selection]

                open(wifi_save_file, 'w').close()  # Open the file and clear it
                f = open(wifi_save_file, "a")  #  Open it again for Append mode
                f.write(selected_wifi)  # Write the selected_response to the file
            exit()

        # Set OLED text line variables
        oled_line_1 = line1
        oled_line_2 = line2
        oled_line_3 = '    ' + line3.strip() + ' (' + str(int(z/10)) + ')'
        oled_line_4 = '     ' + line4
        #oled_line_5 = ' Refresh in ' + '   (' + str(int(z/10)) + ')'
    
        # Draw the text!
        draw.text((9, ((text_multiplier_y*0)+text_offset_y)), oled_line_1, font = font12, fill = 0)
        draw.text((9, ((text_multiplier_y*1)+text_offset_y)), oled_line_2, font = font12, fill = 0)
        draw.text((9, ((text_multiplier_y*2)+text_offset_y)), oled_line_3, font = font12, fill = 0)
        draw.text((9, ((text_multiplier_y*3)+text_offset_y)), oled_line_4, font = font12, fill = 0)

    else: # CENTER button is pressed:
        # Set y-coordinates of selection Box according to the value of "selection" variable
        selection_y1 = ((selection * text_multiplier_y) + 11)
        selection_y2 = ((selection * text_multiplier_y) + 23)

        # Draw the selection Box
        draw.rectangle((8, selection_y1,88,selection_y2), outline=0, fill=1) #center filled
    
        # Get the line that corresponds with the user's selection
        # Read menu items from txt file
        with open(txtfilename, 'r') as f:
            selected_wifi = f.readlines()[selection]

            open(wifi_save_file, 'w').close()  # Open the file and clear it
            f = open(wifi_save_file, "a")  #  Open it again for Append mode
            f.write(selected_wifi)  # Write the selected_response to the file

    
        open(ssid_file, 'w').close()  # Open the file and clear it
        f = open(ssid_file, "a")  #  Open it again for Append mode
        f.write(selected_wifi)  # Write the selected_wifi to the file

        # Clear display.
        disp.clear()
    
        # Draw the text!
        #draw.text((9, 6), oled_line_1, font = font12, fill = 0)
        print("\nSelected WiFi: " + selected_wifi + '\n')
        print("center")

        # Clear display.
        disp.clear()

        # Exit the script
        exit()

        
    if GPIO.input(KEY1_PIN): # button is released
        nothing = 0
        #draw.ellipse((100,0,120,20), outline=255, fill=0) #A button
    else: # button is pressed:
        print("KEY1")
        #draw.ellipse((100,0,120,20), outline=0, fill=1) #A button filled
        
    if GPIO.input(KEY2_PIN): # button is released
        draw.ellipse((100,20,120,40), outline=255, fill=0) #B button]
    else: # button is pressed:
        draw.ellipse((100,20,120,40), outline=0, fill=1) #B button filled
        print("KEY2")
        
    if GPIO.input(KEY3_PIN): # button is released
        draw.ellipse((100,40,120,60), outline=255, fill=0) #A button
    else: # button is pressed:
        draw.ellipse((100,40,120,60), outline=0, fill=1) #A button filled
        print("KEY3")
        
    disp.ShowImage(disp.getbuffer(image))
    
# except:
    # print("except")
# GPIO.cleanup()
