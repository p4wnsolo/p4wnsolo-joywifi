#!/usr/bin/env python
# -*- coding:utf-8 -*-

import SH1106  # OLED library
import time
import config
import traceback
import socket
import fcntl
import struct
import subprocess
import sys
import operator
import pathlib
from pathlib import Path
from operator import itemgetter
from PIL import Image,ImageDraw,ImageFont

# Init variables
prefix = str(pathlib.Path(__file__).parent.resolve()) + '/'
iwlist_file = 'iwlist_results.txt'
ssids_file = prefix + 'ssids.txt'

font1 = 'fonts/Prototype.ttf'
fontsize1 = 18
thefont1 = ImageFont.truetype(prefix + font1, fontsize1)

font2 = 'fonts/Prototype.ttf'
fontsize2 = 14
thefont2 = ImageFont.truetype(prefix + font2, fontsize2)

try:
    disp = SH1106.SH1106()
    disp.Init()
    disp.clear()
    image1 = Image.new('1', (disp.width, disp.height), "WHITE")
    draw = ImageDraw.Draw(image1)
    draw.line([(0,0),(127,0)], fill = 0)
    draw.line([(0,0),(0,63)], fill = 0)
    draw.line([(0,63),(127,63)], fill = 0)
    draw.line([(127,0),(127,63)], fill = 0)
    draw.text((1,2), ' Scanning WiFi', font = thefont1, fill = 0)
    #draw.text((0,32), u'           X Found', font = thefont2, fill = 0)
    #image1=image1.rotate(0) 
    disp.ShowImage(disp.getbuffer(image1))
    #time.sleep(2)
    #Himage2 = Image.new('1', (disp.width, disp.height), 255)
    #bmp = Image.open('pic.bmp')
    #Himage2.paste(bmp, (0,0))    
    #disp.ShowImage(disp.getbuffer(Himage2))
    #time.sleep(2)
    #disp.clear()
    #image2 = Image.new('1', (disp.width, disp.height), "WHITE")
    #draw2 = ImageDraw.Draw(image2)
    #IPAddress = str(get_ip_address())
    #draw2.text((0,0), IPAddress, font = font16, fill = 0)
    #disp.ShowImage(disp.getbuffer(image2))
except IOError as e:
    print(e)
except KeyboardInterrupt:    
    print("ctrl + c:")
    epdconfig.module_exit()
    exit()



# Create a new list 
cells = []


def generateData():
    #wlan = sys.argv[1]  # setting wireless scanning interface

    p = subprocess.Popen("iwlist wlan0 scanning > " + prefix + iwlist_file, shell=True)

    (output, err) = p.communicate()
    p.wait()
    if err:
        return False
    else:
        return True


def checkIfCell(data):
    # receiving stripped data
    if data.split(" ")[0] == "Cell":
        return True
    else:
        return False


def getCellMac(data):
    return data.split("Address:")[1].strip()


def usage():
    print("""
        Usage: python iwlist-parser.py [wlan interface]
        Eg: python iwlist-parser.py wlan0
    """)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        usage()
        sys.exit(1)

    if generateData():
        # parsing data
        iwlist = open(prefix + iwlist_file)
        data = iwlist.readlines()

        parserCount = 0
        cellIndex = -1
        cellBssid = None

        for x in data:
            if parserCount == 0:
                # skip first iteration
                pass
            else:
                currentData = x.strip()

                # check if it's the beginnning of a cell
                if checkIfCell(currentData):
                    cellBssid = getCellMac(currentData)
                    cells.append({'bssid': cellBssid})
                    cellIndex += 1
                else:
                    if cellBssid is not None:
                        iterData = currentData.split(":")
                        if len(iterData) == 2:
                            # formatting data
                            iData0 = iterData[0]
                            iData1 = iterData[1]

                            if iData0 == "Protocol":
                                iterData[1] = iData1.split(".11")[1]

                            if iData0 == "Frequency":
                                dat = iData1.split("GHz")
                                iterData[1] = dat[0].strip()
                                iChannel = dat[1].strip()

                                # retrieving channel parameter
                                cData = iChannel.split(" ")
                                cells[cellIndex].update({cData[0][1:].strip().lower(): cData[1][:-1]})

                            if iData0 == "Bit Rates":
                                iterData[1] = iData1.split("Mb/s")[0].strip()

                            if iData0 == "Extra":
                                wpaData = iData1.split("=")
                                if len(wpaData) == 2:
                                    iterData[0] = wpaData[0].strip().lower()
                                    iterData[1] = wpaData[1]

                                if wpaData[0] == "":
                                    continue

                            cells[cellIndex].update(
                                {"_".join(iterData[0].strip().split(" ")).lower().replace("_(1)", ""): iterData[
                                    1].strip()})
                        elif len(iterData) == 1:
                            # quality and signal level
                            qsData = iterData[0].split("  ")
                            if len(qsData) == 2:
                                quality = qsData[0].split("=")
                                level = qsData[1].split("=")
                                cells[cellIndex].update(
                                    {"_".join(quality[0].split(" ")).lower(): quality[1].split("/")[0].strip(),
                                     "_".join(level[0].split(" ")).lower(): level[1].split("dBm")[0].strip()})

            parserCount += 1

    # Make a new SORTED list from the old unsorted list
    newlist = sorted(cells, key=itemgetter('signal_level')) 


    print('\nNumber of APs detected: ')
    num_aps = str(len(cells))
    
    # Print the number of APs found below the word "Scanning"
    draw.rectangle(((0, 26), (127, 45)), fill="black")
    draw.text((0,25), u'     ' + num_aps + '  Found', font = thefont1, fill = 255)
    draw.text((0,45), '     Please wait..', font = thefont2, fill = 0)

    # Refresh the screen, since we added # of APs found
    disp.ShowImage(disp.getbuffer(image1))

    print(num_aps)
    print('\n')

    # Open the text file
    open(ssids_file, 'w').close()  # Erase it with .close
    f = open(ssids_file, "a")   # Open the file for Append mode

    # Loop through the list of dict entries
    for celnum in newlist:
        myessid = celnum['essid']
        mysig = celnum['signal_level']
        #mycell = newlist[celnum] # Get THIS entire cell
        #myessid = mycell['essid'] 
        myessid = myessid.lstrip('\"')
        myessid = myessid.rstrip('\"')
        debug_myessid = str(celnum) + ') ' + myessid + ' ' + str(mysig) # Get SSID from entire cell
        #print(debug_myessid) # Echo SSID
        if myessid == '':
            print('Skipping Empty SSID when writing to file')
        elif myessid != '':
            print(myessid)
            f.write(myessid + '\n')

    # Close the text file
    f.close()




    #print('End')

    #start = 'essid\': \'\"'
    #end = '\"\', \'bit_rates'
    #s = cells[0]
    #print(s[s.find(start)+len(start):s.rfind(end)])
    print('\n')
    exit()